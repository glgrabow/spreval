# spreval 0.1.0.900 
* development version
* added vignette for traveling systems

# spreval 0.1 (pre-release)

## Vignettes

* 2 vignettes completed

* added vignette for hard-hose traveler forthcoming

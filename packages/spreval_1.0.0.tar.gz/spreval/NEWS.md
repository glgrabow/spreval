# spreval 1.0.0
* version to submit to CRAN
---

# spreval 0.1.0.900 
* development version

* added vignette for traveling systems

[package in github](https://github.com/glgrabow/spreval/blob/master/packages/spreval_0.1.0.900.tar.gz)
---

# spreval 0.1 (pre-release)

* 2 vignettes completed

* added vignette for hard-hose traveler forthcoming

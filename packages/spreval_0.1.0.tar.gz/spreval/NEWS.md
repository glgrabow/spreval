# spreval 0.1 (pre-release)

## Vignettes

* 2 vignettes completed

* additional vignette for hard-hose traveler forthcoming
